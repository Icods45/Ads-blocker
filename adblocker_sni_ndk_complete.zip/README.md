# Android Ad Blocker — SNI + DoH + NDK Starter (Kotlin + C++)

This expanded educational starter includes:
- DNS interception and reply (IPv4+UDP packet builder).
- SNI-based TLS ClientHello inspection to drop TLS connections to blocked hosts (non-MITM).
- Blocking of common DoH providers by hostname/IP.
- Remote blocklist sync using HTTPS + detached signature verification (StevenBlack default URL included).
- NDK/native packet parser skeleton (C++) with JNI bridge for heavy lifting (placeholder; optimize as needed).

Notes:
- Replace placeholder public key and remote URLs with your own production values.
- Test on a real Android device. VPN permission required.
- This is a learning/example project. Use responsibly and test apps for breakage.
