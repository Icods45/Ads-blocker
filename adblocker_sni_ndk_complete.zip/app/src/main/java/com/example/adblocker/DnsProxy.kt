package com.example.adblocker

object DnsProxy {
    fun buildDnsAnswerPayload(request: ByteArray, reqLen: Int): ByteArray {
        val id0 = request[0]
        val id1 = request[1]
        val header = ByteArray(12)
        header[0] = id0; header[1] = id1
        header[2] = 0x81.toByte(); header[3] = 0x80.toByte()
        header[4] = request[4]; header[5] = request[5]
        header[6] = 0x00; header[7] = 0x01
        header[8] = 0x00; header[9] = 0x00
        header[10] = 0x00; header[11] = 0x00
        val questionLen = reqLen - 12
        val response = ByteArray(12 + questionLen + 16)
        System.arraycopy(header, 0, response, 0, 12)
        System.arraycopy(request, 12, response, 12, questionLen)
        var ansOff = 12 + questionLen
        response[ansOff++] = 0xC0.toByte(); response[ansOff++] = 0x0C
        response[ansOff++] = 0x00.toByte(); response[ansOff++] = 0x01.toByte()
        response[ansOff++] = 0x00.toByte(); response[ansOff++] = 0x01.toByte()
        response[ansOff++] = 0x00; response[ansOff++] = 0x00; response[ansOff++] = 0x00; response[ansOff++] = 0x3C
        response[ansOff++] = 0x00; response[ansOff++] = 0x04
        response[ansOff++] = 0x00; response[ansOff++] = 0x00; response[ansOff++] = 0x00; response[ansOff++] = 0x00
        return response
    }

    fun buildIpUdpPacket(udpPayload: ByteArray, srcIp: ByteArray, dstIp: ByteArray, srcPort: Int, dstPort: Int): ByteArray {
        val ipHeaderOut = ByteArray(20)
        ipHeaderOut[0] = 0x45.toByte(); ipHeaderOut[1] = 0x00
        val totalLen = 20 + 8 + udpPayload.size
        ipHeaderOut[2] = ((totalLen shr 8) and 0xFF).toByte(); ipHeaderOut[3] = (totalLen and 0xFF).toByte()
        ipHeaderOut[4] = 0x00; ipHeaderOut[5] = 0x00
        ipHeaderOut[6] = 0x00; ipHeaderOut[7] = 0x00
        ipHeaderOut[8] = 0x40
        ipHeaderOut[9] = 17
        ipHeaderOut[10] = 0x00; ipHeaderOut[11] = 0x00
        System.arraycopy(srcIp, 0, ipHeaderOut, 12, 4)
        System.arraycopy(dstIp, 0, ipHeaderOut, 16, 4)
        val udpHeader = ByteArray(8)
        udpHeader[0] = ((srcPort shr 8) and 0xFF).toByte(); udpHeader[1] = (srcPort and 0xFF).toByte()
        udpHeader[2] = ((dstPort shr 8) and 0xFF).toByte(); udpHeader[3] = (dstPort and 0xFF).toByte()
        val udpLen = 8 + udpPayload.size
        udpHeader[4] = ((udpLen shr 8) and 0xFF).toByte(); udpHeader[5] = (udpLen and 0xFF).toByte()
        udpHeader[6] = 0x00; udpHeader[7] = 0x00
        val checksum = ipChecksum(ipHeaderOut)
        ipHeaderOut[10] = ((checksum shr 8) and 0xFF).toByte(); ipHeaderOut[11] = (checksum and 0xFF).toByte()
        val out = ByteArray(ipHeaderOut.size + udpHeader.size + udpPayload.size)
        var pos = 0
        System.arraycopy(ipHeaderOut, 0, out, pos, ipHeaderOut.size); pos += ipHeaderOut.size
        System.arraycopy(udpHeader, 0, out, pos, udpHeader.size); pos += udpHeader.size
        System.arraycopy(udpPayload, 0, out, pos, udpPayload.size)
        return out
    }

    private fun ipChecksum(buf: ByteArray): Int {
        var sum = 0
        var i = 0
        while (i < 20) {
            if (i == 10) { i += 2; continue }
            val hi = (buf[i].toInt() and 0xFF) shl 8
            val lo = (buf[i+1].toInt() and 0xFF)
            sum += hi + lo
            if (sum and 0xFFFF0000.toInt() != 0) sum = (sum and 0xFFFF) + (sum shr 16)
            i += 2
        }
        sum = sum.inv() and 0xFFFF
        return sum
    }
}
