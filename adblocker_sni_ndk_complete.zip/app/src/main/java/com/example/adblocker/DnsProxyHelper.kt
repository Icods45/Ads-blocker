package com.example.adblocker

object DnsProxyHelper {
    fun parseQuestionName(packet: ByteArray, off: Int, len: Int): String? {
        try {
            var idx = off
            val parts = ArrayList<String>()
            while (idx < off + len) {
                val l = packet[idx].toInt() and 0xFF
                if (l == 0) return parts.joinToString(".")
                idx += 1
                if (idx + l > off + len) return null
                parts.add(String(packet, idx, l))
                idx += l
            }
            return null
        } catch (e: Exception) { return null }
    }
}
