package com.example.adblocker

object SniUtils {
    fun parseSniFromClientHello(payload: ByteArray, offset: Int, length: Int): String? {
        try {
            var pos = offset
            if (length < 5) return null
            val contentType = payload[pos].toInt() and 0xFF
            if (contentType != 0x16) return null
            val recLen = ((payload[pos+3].toInt() and 0xFF) shl 8) or (payload[pos+4].toInt() and 0xFF)
            pos += 5
            if (recLen + 5 > length) return null
            val hsType = payload[pos].toInt() and 0xFF
            if (hsType != 0x01) return null
            val hsLen = ((payload[pos+1].toInt() and 0xFF) shl 16) or ((payload[pos+2].toInt() and 0xFF) shl 8) or (payload[pos+3].toInt() and 0xFF)
            pos += 4
            pos += 2 + 32
            val sessionIdLen = payload[pos].toInt() and 0xFF; pos += 1 + sessionIdLen
            val csLen = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos+1].toInt() and 0xFF)
            pos += 2 + csLen
            val compLen = payload[pos].toInt() and 0xFF; pos += 1 + compLen
            val extLen = ((payload[pos].toInt() and 0xFF) shl 8) or (payload[pos+1].toInt() and 0xFF)
            pos += 2
            var extPos = pos
            while (extPos + 4 <= pos + extLen) {
                val extType = ((payload[extPos].toInt() and 0xFF) shl 8) or (payload[extPos+1].toInt() and 0xFF)
                val extL = ((payload[extPos+2].toInt() and 0xFF) shl 8) or (payload[extPos+3].toInt() and 0xFF)
                extPos += 4
                if (extType == 0x00) {
                    var namePos = extPos
                    val listLen = ((payload[namePos].toInt() and 0xFF) shl 8) or (payload[namePos+1].toInt() and 0xFF)
                    namePos += 2
                    while (namePos + 3 < extPos + extL) {
                        val nameType = payload[namePos].toInt() and 0xFF
                        val nameLen = ((payload[namePos+1].toInt() and 0xFF) shl 8) or (payload[namePos+2].toInt() and 0xFF)
                        namePos += 3
                        if (nameType == 0) {
                            if (namePos + nameLen <= extPos + extL) {
                                return String(payload, namePos, nameLen)
                            } else return null
                        } else {
                            namePos += nameLen
                        }
                    }
                }
                extPos += extL
            }
            return null
        } catch (e: Exception) {
            return null
        }
    }
}
