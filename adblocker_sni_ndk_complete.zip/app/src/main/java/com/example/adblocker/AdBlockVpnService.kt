package com.example.adblocker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import kotlin.concurrent.thread

class AdBlockVpnService : VpnService() {
    private var vpnInterface: ParcelFileDescriptor? = null
    @Volatile private var running = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        startForeground(1, createNotification())

        if (vpnInterface == null) {
            val builder = Builder()
                .setSession("AdBlockVPN")
                .addAddress("10.0.0.2", 24)
                .addDnsServer("8.8.8.8")
                .addRoute("0.0.0.0", 0)
            vpnInterface = builder.establish()
        }

        running = true
        vpnInterface?.let { pfd ->
            thread(start = true) { runVpnLoop(pfd.fileDescriptor) }
        }

        val bm = BlocklistManager.getInstance(this)
        bm.loadFromAssets()
        bm.resolveBlockedDomainsAsync()
        bm.resolveDohProvidersAsync()

        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        vpnInterface?.close()
        vpnInterface = null
        super.onDestroy()
    }

    private fun runVpnLoop(fd: java.io.FileDescriptor) {
        val input = FileInputStream(fd)
        val output = FileOutputStream(fd)
        val packet = ByteArray(32767)

        while (running) {
            try {
                val length = input.read(packet)
                if (length <= 0) continue
                val version = (packet[0].toInt() shr 4) and 0xF
                if (version == 4) {
                    val proto = packet[9].toInt() and 0xFF
                    if (proto == 17) { // UDP (likely DNS)
                        val ihl = (packet[0].toInt() and 0x0F) * 4
                        val srcIp = byteArrayOf(packet[12], packet[13], packet[14], packet[15])
                        val dstIp = byteArrayOf(packet[16], packet[17], packet[18], packet[19])
                        val srcPort = ((packet[ihl].toInt() and 0xFF) shl 8) or (packet[ihl+1].toInt() and 0xFF)
                        val dstPort = ((packet[ihl+2].toInt() and 0xFF) shl 8) or (packet[ihl+3].toInt() and 0xFF)
                        if (dstPort == 53) {
                            val dnsOffset = ihl + 8
                            val qname = DnsProxyHelper.parseQuestionName(packet, dnsOffset + 12, length - dnsOffset - 12)
                            if (qname != null) {
                                val bm = BlocklistManager.getInstance(this)
                                if (bm.isBlockedDomain(qname)) {
                                    val dnsAnswer = DnsProxy.buildDnsAnswerPayload(packet, length - dnsOffset)
                                    val replyPacket = DnsProxy.buildIpUdpPacket(dnsAnswer, dstIp, srcIp, 53, srcPort)
                                    output.write(replyPacket)
                                    continue
                                }
                            }
                        }
                        val dstIpStr = String.format("%d.%d.%d.%d", packet[16].toInt() and 0xFF, packet[17].toInt() and 0xFF, packet[18].toInt() and 0xFF, packet[19].toInt() and 0xFF)
                        val bm = BlocklistManager.getInstance(this)
                        if (bm.isBlockedIp(dstIpStr) || bm.dohIps.contains(dstIpStr)) {
                            continue
                        }
                    } else if (proto == 6) { // TCP -> possible TLS ClientHello
                        val ihl = (packet[0].toInt() and 0x0F) * 4
                        val tcpOffset = ihl
                        if (length > tcpOffset + 5) {
                            val dataOffset = ((packet[tcpOffset+12].toInt() shr 4) and 0xF) * 4
                            val payloadStart = tcpOffset + dataOffset
                            if (payloadStart < length) {
                                val sni = SniUtils.parseSniFromClientHello(packet, payloadStart, length - payloadStart)
                                if (sni != null) {
                                    val bm = BlocklistManager.getInstance(this)
                                    if (bm.isBlockedDomain(sni) || bm.isDohDomain(sni)) {
                                        continue
                                    }
                                }
                            }
                        }
                    }
                }
                output.write(packet, 0, length)
            } catch (e: Exception) {
                e.printStackTrace()
                break
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel("adblock_vpn", "AdBlock VPN", NotificationManager.IMPORTANCE_LOW)
            nm.createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, "adblock_vpn")
        } else {
            Notification.Builder(this)
        }
        builder.setContentTitle("AdBlock VPN")
            .setContentText("Running")
        return builder.build()
    }
}
