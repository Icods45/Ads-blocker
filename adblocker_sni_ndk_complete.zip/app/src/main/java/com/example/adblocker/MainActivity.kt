package com.example.adblocker

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private val VPN_REQUEST_CODE = 0x100
    private lateinit var statusTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val startBtn = Button(this).apply { text = "Start AdBlock VPN" }
        val stopBtn = Button(this).apply { text = "Stop AdBlock VPN" }
        val syncBtn = Button(this).apply { text = "Sync blocklist (placeholder)" }
        statusTv = TextView(this).apply { text = "Status: stopped" }

        layout.addView(startBtn)
        layout.addView(stopBtn)
        layout.addView(syncBtn)
        layout.addView(statusTv)
        setContentView(layout)

        startBtn.setOnClickListener {
            val intent = VpnService.prepare(this)
            if (intent != null) startActivityForResult(intent, VPN_REQUEST_CODE)
            else startService(Intent(this, AdBlockVpnService::class.java))
        }
        stopBtn.setOnClickListener {
            stopService(Intent(this, AdBlockVpnService::class.java))
            statusTv.text = "Status: stopped"
        }
        syncBtn.setOnClickListener {
            BlocklistManager.getInstance(this).syncFromRemote()
        }

        // warmup native lib (load JNI)
        try { System.loadLibrary("packetparser") } catch (e: Throwable) {}
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == VPN_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            startService(Intent(this, AdBlockVpnService::class.java))
            statusTv.text = "Status: running"
        }
    }
}
