package com.example.adblocker

class PacketParser {
    external fun nativeHello(): String
}
