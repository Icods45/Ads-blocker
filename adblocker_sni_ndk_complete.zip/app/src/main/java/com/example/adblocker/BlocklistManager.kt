package com.example.adblocker

import android.content.Context
import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.net.InetAddress
import java.util.concurrent.ConcurrentHashMap

class BlocklistManager private constructor(private val context: Context) {
    private val blockedDomains = HashSet<String>()
    private val dohDomains = HashSet<String>()
    // resolved IPs for quick dropping
    val blockedIps = ConcurrentHashMap.newKeySet<String>()
    val dohIps = ConcurrentHashMap.newKeySet<String>()
    private val ioScope = CoroutineScope(Dispatchers.IO + Job())

    // Remote sync defaults (StevenBlack unified hosts raw URL as default)
    private val REMOTE_LIST_URL = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
    private val REMOTE_SIG_URL  = "https://example.com/blocklist.txt.sig" // replace with your sig endpoint

    // common DoH provider hostnames to block or monitor
    private val DEFAULT_DOH_PROVIDERS = listOf(
        "dns.google",
        "dns.adguard.com",
        "cloudflare-dns.com",
        "mozilla.cloudflare-dns.com",
        "dns.quad9.net",
        "1dot1dot1dot1.cloudflare-dns.com",
        "doh.cleanbrowsing.org"
    )

    companion object {
        @Volatile
        private var INSTANCE: BlocklistManager? = null

        fun getInstance(context: Context): BlocklistManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: BlocklistManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    fun loadFromAssets(assetName: String = "blocklist.txt") {
        context.assets.open(assetName).use { stream ->
            BufferedReader(stream.reader()).useLines { lines ->
                lines.map { it.trim() }
                    .filter { it.isNotEmpty() && !it.startsWith("#") }
                    .forEach { blockedDomains.add(it) }
            }
        }
        // add default doh providers to dohDomains set
        DEFAULT_DOH_PROVIDERS.forEach { dohDomains.add(it) }
    }

    private fun loadFromString(listData: String) {
        blockedDomains.clear()
        listData.lines()
            .map { l ->
                val s = l.trim()
                if (s.startsWith("0.0.0.0") || s.startsWith("127.0.0.1")) {
                    val parts = s.split(Regex("\\s+"))
                    if (parts.size >= 2) return@map parts[1] else return@map ""
                }
                return@map s
            }
            .filter { it.isNotEmpty() && !it.startsWith("#") }
            .forEach { blockedDomains.add(it) }
    }

    fun isBlockedDomain(domain: String): Boolean {
        if (blockedDomains.contains(domain)) return true
        val parts = domain.split('.')
        for (i in 1 until parts.size) {
            val sub = parts.subList(i, parts.size).joinToString(".")
            if (blockedDomains.contains(sub)) return true
        }
        return false
    }

    fun isDohDomain(domain: String): Boolean = dohDomains.contains(domain)

    fun isBlockedIp(ip: String): Boolean = blockedIps.contains(ip)

    fun resolveBlockedDomainsAsync() {
        ioScope.launch {
            blockedIps.clear()
            val jobs = blockedDomains.map { domain ->
                async {
                    try {
                        val addrs = InetAddress.getAllByName(domain)
                        addrs.forEach { blockedIps.add(it.hostAddress) }
                    } catch (e: Exception) {
                        // ignore resolution failures
                    }
                }
            }
            jobs.awaitAll()
        }
    }

    fun resolveDohProvidersAsync() {
        ioScope.launch {
            dohIps.clear()
            val jobs = dohDomains.map { domain ->
                async {
                    try {
                        val addrs = InetAddress.getAllByName(domain)
                        addrs.forEach { dohIps.add(it.hostAddress) }
                    } catch (e: Exception) {
                        // ignore
                    }
                }
            }
            jobs.awaitAll()
        }
    }

    fun syncFromRemote(listUrl: String = REMOTE_LIST_URL, sigUrl: String = REMOTE_SIG_URL) {
        ioScope.launch {
            try {
                val client = OkHttpClient()

                val reqList = Request.Builder().url(listUrl).get().build()
                val respList = client.newCall(reqList).execute()
                if (!respList.isSuccessful) throw Exception("Failed to download list: ${respList.code}")
                val listBytes = respList.body?.bytes() ?: throw Exception("Empty list body")

                var verified = true
                if (!sigUrl.contains("example.com")) {
                    val reqSig = Request.Builder().url(sigUrl).get().build()
                    val respSig = client.newCall(reqSig).execute()
                    if (!respSig.isSuccessful) throw Exception("Failed to download signature: ${respSig.code}")
                    val sigBytes = respSig.body?.bytes() ?: throw Exception("Empty sig body")
                    verified = CryptoUtils.verifyWithEmbeddedPublicKey(listBytes, sigBytes)
                }

                if (!verified) throw Exception("Signature verification failed")
                val listString = String(listBytes)
                loadFromString(listString)
                val cacheFile = File(context.filesDir, "blocklist_cached.txt")
                FileOutputStream(cacheFile).use { it.write(listBytes) }
                resolveBlockedDomainsAsync()
                resolveDohProvidersAsync()
            } catch (e: Exception) {
                e.printStackTrace()
                try {
                    val cacheFile = File(context.filesDir, "blocklist_cached.txt")
                    if (cacheFile.exists()) {
                        val cached = cacheFile.readText()
                        loadFromString(cached)
                        resolveBlockedDomainsAsync()
                        resolveDohProvidersAsync()
                    }
                } catch (ex: Exception) { ex.printStackTrace() }
            }
        }
    }
}
