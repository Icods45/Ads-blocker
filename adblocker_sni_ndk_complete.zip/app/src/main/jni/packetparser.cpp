#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_adblocker_PacketParser_nativeHello(JNIEnv* env, jobject /* this */) {
    std::string hello = "native-packet-parser-loaded";
    return env->NewStringUTF(hello.c_str());
}
